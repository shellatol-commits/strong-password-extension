document.getElementById('btn').addEventListener('click', () => {
  const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+";
  let password = "";
  const values = new Uint32Array(30);
  window.crypto.getRandomValues(values);
  for (let i = 0; i < 30; i++) {
    password += charset[values[i] % charset.length];
  }
  document.getElementById('pass').innerText = password;
  navigator.clipboard.writeText(password);
});